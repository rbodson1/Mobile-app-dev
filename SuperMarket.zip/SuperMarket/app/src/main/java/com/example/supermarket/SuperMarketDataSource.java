package com.example.supermarket;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import java.sql.SQLException;

public class SuperMarketDataSource {
    private SQLiteDatabase database;
    private SuperMarketDBHelper dbHelper;

    public SuperMarketDataSource(Context context) {
        dbHelper = new SuperMarketDBHelper(context);
    }

    public void open() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }


    public boolean insertSupermarket(SuperMarket s) {
        boolean didSucceed = false;
        try {
            ContentValues initialValues = new ContentValues();

            initialValues.put("streetaddress", s.getStreetAddress());
            initialValues.put("city", s.getCity());
            initialValues.put("state", s.getState());
            initialValues.put("zipcode", s.getZipCode());
            initialValues.put("liquorrating", s.getLiquorRating());
            initialValues.put("producerating", s.getProduceRating());
            initialValues.put("meatrating", s.getMeatRating());
            initialValues.put("cheeserating", s.getCheeseRating());
            initialValues.put("checkoutrating", s.getCheckoutRating());


            didSucceed = database.insert("supermarket", null, initialValues) > 0;

        }
        catch (Exception e) {
            //Do nothing -will return false if there is an exception
        }
        return didSucceed;
    }

    public boolean updateSupermarket(SuperMarket s) {
        boolean didSucceed = false;
        try {
            long rowid = (long) s.getSupermarketID();
            ContentValues updateValues = new ContentValues();

            updateValues.put("streetaddress", s.getStreetAddress());
            updateValues.put("city", s.getCity());
            updateValues.put("state", s.getState());
            updateValues.put("zipcode", s.getZipCode());
            updateValues.put("liquorrating", s.getLiquorRating());
            updateValues.put("producerating", s.getProduceRating());
            updateValues.put("meatrating", s.getMeatRating());
            updateValues.put("cheeserating", s.getCheeseRating());
            updateValues.put("checkoutrating", s.getCheckoutRating());

            didSucceed = database.update("supermarket", updateValues, "_id=" + rowid, null) > 0;
        }
        catch (Exception e) {
            //Do nothing -will return false if there is an exception
        }
        return didSucceed;
    }

}
