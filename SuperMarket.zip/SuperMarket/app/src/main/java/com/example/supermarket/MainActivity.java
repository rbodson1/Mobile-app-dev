package com.example.supermarket;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initRateButton();
    }

    private void initRateButton() {
        Button button = findViewById(R.id.button_rating);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText editName = findViewById(R.id.editText_restaurant);
                EditText editStreet = findViewById(R.id.editText_address);
                EditText editCity = findViewById(R.id.editText_city);
                EditText editState = findViewById(R.id.editText_state);
                EditText editZip = findViewById(R.id.editText_zipcode);

                getSharedPreferences("myPreferences", MODE_PRIVATE).edit().putString("name", editName.getText().toString() ).apply();
                getSharedPreferences("myPreferences", MODE_PRIVATE).edit().putString("address", editStreet.getText().toString() ).apply();
                getSharedPreferences("myPreferences", MODE_PRIVATE).edit().putString("city", editCity.getText().toString() ).apply();
                getSharedPreferences("myPreferences", MODE_PRIVATE).edit().putString("state", editState.getText().toString() ).apply();
                getSharedPreferences("myPreferences", MODE_PRIVATE).edit().putString("zip", editZip.getText().toString() ).apply();

                Intent intent = new Intent(MainActivity.this, RatingActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });
    }
}
