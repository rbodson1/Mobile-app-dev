package com.example.supermarket;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

public class RatingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rating);

        initSaveButton();
        initBackButton();
    }

    private void initSaveButton() {
        Button button = findViewById(R.id.button_save);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SuperMarket superMarket = new SuperMarket();
                SharedPreferences preferences = getSharedPreferences("myPreferences", MODE_PRIVATE);

                superMarket.setSupermarket(preferences.getString("name", "not set"));
                superMarket.setStreetAddress(preferences.getString("address", "not set"));
                superMarket.setCity(preferences.getString("city", "not set"));
                superMarket.setState(preferences.getString("state", "not set"));
                superMarket.setZipCode(preferences.getString("zip", "not set"));

                RatingBar ratingLiquor = findViewById(R.id.ratingBar_liquor);
                RatingBar ratingProduce = findViewById(R.id.ratingBar_produce);
                RatingBar ratingMeat = findViewById(R.id.ratingBar_meat);
                RatingBar ratingCheese = findViewById(R.id.ratingBar_cheese);
                RatingBar ratingCheckout = findViewById(R.id.ratingBar_checkout);

                superMarket.setLiquorRating(ratingLiquor.getRating());
                superMarket.setProduceRating(ratingProduce.getRating());
                superMarket.setMeatRating(ratingMeat.getRating());
                superMarket.setCheeseRating(ratingCheese.getRating());
                superMarket.setCheckoutRating(ratingCheckout.getRating());

                double averageRating = 0;
                averageRating += superMarket.getLiquorRating();
                averageRating += superMarket.getProduceRating();
                averageRating += superMarket.getMeatRating();
                averageRating += superMarket.getCheeseRating();
                averageRating += superMarket.getCheckoutRating();
                averageRating = averageRating/5;

                TextView textView = findViewById(R.id.textView_rating);
                textView.setText(String.valueOf(averageRating));

                SuperMarketDataSource ds = new SuperMarketDataSource(RatingActivity.this);
                boolean wasSuccessful;
                try {
                    ds.open();
                    if (superMarket.getSupermarketID() == -1) {
                        wasSuccessful = ds.insertSupermarket(superMarket);
                    }
                    else {
                        wasSuccessful = ds.updateSupermarket(superMarket);
                    }
                    ds.close();

                }
                catch (Exception e) {
                    wasSuccessful = false;
                    ds.close();
                }

                if (wasSuccessful) {
                    Toast.makeText(RatingActivity.this, "Supermarket Saved!", Toast.LENGTH_LONG).show();
                }
                else {
                    Toast.makeText(RatingActivity.this, "Supermarket Save Failed!", Toast.LENGTH_LONG).show();
                }

            }
        });
    }

    private void initBackButton() {
        Button button = findViewById(R.id.button_back);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(RatingActivity.this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);

            }
        });
    }
}
