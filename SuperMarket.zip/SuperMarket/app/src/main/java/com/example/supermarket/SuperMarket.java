package com.example.supermarket;

public class SuperMarket {
    private int supermarketID;
    private String supermarket;
    private String streetAddress;
    private String city;
    private String state;
    private String zipCode;
    private float liquorRating;
    private float produceRating;
    private float meatRating;
    private float cheeseRating;
    private float checkoutRating;

    public SuperMarket() {
        supermarketID = -1;
        liquorRating = 0;
        produceRating = 0;
        meatRating = 0;
        cheeseRating = 0;
        checkoutRating = 0;
    }

    public float getLiquorRating() {
        return liquorRating;
    }

    public float getProduceRating() {
        return produceRating;
    }

    public float getMeatRating() {
        return meatRating;
    }

    public int getSupermarketID() {
        return supermarketID;
    }

    public String getCity() {
        return city;
    }

    public String getSupermarket() {
        return supermarket;
    }

    public String getState() {
        return state;
    }

    public String getStreetAddress() {
        return streetAddress;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setLiquorRating(float liquorRating) {
        this.liquorRating = liquorRating;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setProduceRating(float produceRating) {
        this.produceRating = produceRating;
    }

    public void setSupermarket(String supermarket) {
        this.supermarket = supermarket;
    }

    public void setSupermarketID(int supermarketID) {
        this.supermarketID = supermarketID;
    }

    public void setState(String state) {
        this.state = state;
    }

    public void setStreetAddress(String streetAddress) {
        this.streetAddress = streetAddress;
    }

    public void setMeatRating(float meatRating) {
        this.meatRating = meatRating;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public float getCheckoutRating() {
        return checkoutRating;
    }

    public void setCheckoutRating(float checkoutRating) {
        this.checkoutRating = checkoutRating;
    }

    public float getCheeseRating() {
        return cheeseRating;
    }

    public void setCheeseRating(float cheeseRating) {
        this.cheeseRating = cheeseRating;
    }
}
