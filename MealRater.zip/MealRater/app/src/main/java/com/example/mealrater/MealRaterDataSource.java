package com.example.mealrater;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import java.sql.SQLException;

public class MealRaterDataSource {

    private SQLiteDatabase database;
    private DBMealRaterHelper dbHelper;

    public MealRaterDataSource(Context context) {
        dbHelper = new DBMealRaterHelper(context);
    }

    public void open() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public boolean insertMeal(Meal m) {
        boolean didSucceed = false;
        try {
            ContentValues initialValues = new ContentValues();

            initialValues.put("restaurantname", m.getRestaurantName());
            initialValues.put("dish", m.getMealName());
            initialValues.put("mealrating", m.getMealRating());

            didSucceed = database.insert("mealrating", null, initialValues) > 0;
        }
        catch (Exception e) {
            //Do nothing -will return false if there is an exception
        }
        return didSucceed;
    }

    public boolean updateMeal(Meal m) {
        boolean didSucceed = false;
        try {
            Long rowId = (long) m.getMealID();
            ContentValues updateValues = new ContentValues();

            updateValues.put("restaurantname", m.getRestaurantName());
            updateValues.put("dish", m.getMealName());
            updateValues.put("mealrating", m.getMealRating());

            didSucceed = database.update("mealrating", updateValues, "_id=" + rowId, null) > 0;
        }
        catch (Exception e) {
            //Do nothing -will return false if there is an exception
        }
        return didSucceed;
    }

}
