package com.example.mealrater;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;

public class RestaurantList extends AppCompatActivity {
    ArrayList<Meal> meals;
    RecyclerView mealList;
    RestaurantAdapter restaurantAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurant_list);

        initBackButton();
    }

    @Override
    public void onResume() {
        super.onResume();

        MealRaterDataSource ds = new MealRaterDataSource(this);

        try {
            ds.open();
            meals = ds.getMeals();
            ds.close();
            if (meals.size() > 0) {
                mealList = findViewById(R.id.recyclerView_meals);
                RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
                mealList.setLayoutManager(layoutManager);
                restaurantAdapter = new RestaurantAdapter(meals, this);
                mealList.setAdapter(restaurantAdapter);
            }
            else {
                Intent intent = new Intent(RestaurantList.this, MainActivity.class);
                startActivity(intent);
            }
        }
        catch (Exception e) {
            Toast.makeText(this, "Error retrieving contacts", Toast.LENGTH_LONG).show();
        }

    }

    private void initBackButton() {
        Button button = findViewById(R.id.button_back);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(RestaurantList.this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });
    }


}
