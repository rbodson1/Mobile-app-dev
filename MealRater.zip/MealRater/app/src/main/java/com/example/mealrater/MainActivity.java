package com.example.mealrater;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements MealRaterDialog.SaveRatingListener {

    private Meal currentMeal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initRatingButton();
        initSaveButton();
        initListButton();

        currentMeal = new Meal();
    }

    private void initRatingButton() {
        Button button = findViewById(R.id.button_rate);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentManager fragmentManager = getSupportFragmentManager();
                MealRaterDialog mealRaterDialog = new MealRaterDialog();
                mealRaterDialog.show(fragmentManager, "RateMeal");
            }
        });
    }

    private void initSaveButton() {
        Button button = findViewById(R.id.button_save);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText editRestaurant = findViewById(R.id.editText_restaurant);
                EditText editDish = findViewById(R.id.editText_dish);
                TextView txtRating = findViewById(R.id.textView_userRating);

                currentMeal.setRestaurantName(editRestaurant.getText().toString());
                currentMeal.setMealName(editDish.getText().toString());
                currentMeal.setMealRating(Float.valueOf(txtRating.getText().toString()));

                MealRaterDataSource ds = new MealRaterDataSource(MainActivity.this);
                boolean wasSuccessful;
                try {
                    ds.open();
                    if (currentMeal.getMealID() == -1) {
                        wasSuccessful = ds.insertMeal(currentMeal);
                    }
                    else {
                        wasSuccessful = ds.updateMeal(currentMeal);
                    }
                    ds.close();

                }
                catch (Exception e) {
                    wasSuccessful = false;
                    ds.close();
                }

                if (wasSuccessful) {
                    Toast.makeText(MainActivity.this, "Rating Saved!", Toast.LENGTH_LONG).show();
                }
                else {
                    Toast.makeText(MainActivity.this, "Rating Save Failed!", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private void initListButton() {
        Button button = findViewById(R.id.button_list);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, RestaurantList.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });
    }
    @Override
    public void didFinishMealRaterDialog(float rating) {
        TextView textView = findViewById(R.id.textView_userRating);
        textView.setText(String.valueOf(rating));
    }
}
