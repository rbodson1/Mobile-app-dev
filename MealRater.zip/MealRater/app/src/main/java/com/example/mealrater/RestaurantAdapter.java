package com.example.mealrater;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import androidx.annotation.NonNull;

import java.util.ArrayList;

public class RestaurantAdapter extends RecyclerView.Adapter{
    private ArrayList<Meal> mealData;


    public class RestaurantViewHolder extends RecyclerView.ViewHolder {

        public TextView textViewRestaurant;
        public TextView textViewMeal;
        public RestaurantViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewRestaurant = itemView.findViewById(R.id.textView_restaurantlist);
            textViewMeal = itemView.findViewById(R.id.textView_meallist);
            itemView.setTag(this);

        }

        public TextView getTextViewRestaurant() {
            return textViewRestaurant;
        }
        public TextView getTextViewMeal() {
            return textViewMeal;
        }
    }

    public RestaurantAdapter(ArrayList<Meal> arrayList, Context context) {
        mealData = arrayList;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.restaurant_layout, parent, false);
        return new RestaurantViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position) {
        RestaurantViewHolder rvh = (RestaurantViewHolder) holder;
        rvh.getTextViewRestaurant().setText(mealData.get(position).getRestaurantName());
        rvh.getTextViewMeal().setText(mealData.get(position).getMealName());

    }

    @Override
    public int getItemCount() {
        return mealData.size();
    }

}
