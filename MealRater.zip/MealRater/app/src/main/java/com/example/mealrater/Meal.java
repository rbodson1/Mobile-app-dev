package com.example.mealrater;

public class Meal {
    private int mealID;
    private String restaurantName;
    private String mealName;
    private float mealRating;


    public Meal() {
        mealID = -1;
    }

    public int getMealID() {
        return mealID;
    }
    public void setMealID(int i) {
        mealID = i;
    }
    public String getRestaurantName() {
        return restaurantName;
    }
    public void setRestaurantName(String s) {
        restaurantName = s;
    }

    public String getMealName() {
        return mealName;
    }
    public void setMealName(String s) {
        mealName = s;
    }
    public void setMealRating(float f) {
        mealRating = f;
    }
    public float getMealRating() {
        return mealRating;
    }

}
