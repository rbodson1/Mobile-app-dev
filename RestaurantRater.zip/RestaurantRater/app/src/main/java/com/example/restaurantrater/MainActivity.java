package com.example.restaurantrater;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initRateButton();
    }

    private void initRateButton() {
        Button button = findViewById(R.id.button_rating);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Restaurant restaurant = new Restaurant();
                EditText editName = findViewById(R.id.editText_restaurant);
                EditText editStreet = findViewById(R.id.editText_address);
                EditText editCity = findViewById(R.id.editText_city);
                EditText editState = findViewById(R.id.editText_state);
                EditText editZip = findViewById(R.id.editText_zipcode);

                restaurant.setRestaurant(editName.getText().toString());
                restaurant.setStreetAddress(editStreet.getText().toString());
                restaurant.setCity(editCity.getText().toString());
                restaurant.setState(editState.getText().toString());
                restaurant.setZipCode(editZip.getText().toString());

                int restaurantId = -1;
                RestaurantDataSource ds = new RestaurantDataSource(MainActivity.this);
                boolean wasSuccessful;
                try {
                    ds.open();
                    if (restaurant.getRestaurantID() == -1) {
                        wasSuccessful = ds.insertRestaurant(restaurant);
                        restaurantId = ds.getLastRestaurantId();
                    }
                    else {
                        wasSuccessful = ds.updateRestuarant(restaurant);
                        restaurantId = restaurant.getRestaurantID();
                    }
                    ds.close();

                }
                catch (Exception e) {
                    wasSuccessful = false;
                    ds.close();
                }

                if (wasSuccessful) {
                    getSharedPreferences("myPreferences", MODE_PRIVATE).edit().putInt("id", restaurantId).apply();
                    Intent intent = new Intent(MainActivity.this, RatingActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                }
                else {
                    Toast.makeText(MainActivity.this, "Restaurant Save Failed!", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

}
