package com.example.restaurantrater;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Toast;

public class RatingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rating);

        initSaveButton();
    }

    private void initSaveButton() {
        Button button = findViewById(R.id.button_save);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dish dish = new Dish();
                dish.setRestuarantID(getSharedPreferences("myPreferences", MODE_PRIVATE).getInt("id", -1));

                EditText editName = findViewById(R.id.editText_dishname);
                EditText editType = findViewById(R.id.editText_dishtype);
                RatingBar ratingBar = findViewById(R.id.ratingBar_dish);

                dish.setDishName(editName.getText().toString());
                dish.setType(editType.getText().toString());
                dish.setRating(ratingBar.getRating());

                RestaurantDataSource ds = new RestaurantDataSource(RatingActivity.this);
                boolean wasSuccessful;
                try {
                    ds.open();
                    if (dish.getDishID() == -1) {
                        wasSuccessful = ds.insertDish(dish);
                    }
                    else {
                        wasSuccessful = ds.updateDish(dish);
                    }
                    ds.close();

                }
                catch (Exception e) {
                    wasSuccessful = false;
                    ds.close();
                }

                if (wasSuccessful) {
                    Toast.makeText(RatingActivity.this, "Dish Saved!", Toast.LENGTH_LONG).show();
                }
                else {
                    Toast.makeText(RatingActivity.this, "Dish Save Failed!", Toast.LENGTH_LONG).show();
                }

            }
        });
    }
}
