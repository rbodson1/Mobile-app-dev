package com.example.restaurantrater;

public class Dish {
    private int dishID;
    private String dishName;
    private String type;
    private float rating;
    private int restuarantID;

    public Dish() {
        dishID = -1;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public float getRating() {
        return rating;
    }

    public int getDishID() {
        return dishID;
    }

    public int getRestuarantID() {
        return restuarantID;
    }

    public String getDishName() {
        return dishName;
    }

    public void setDishID(int dishID) {
        this.dishID = dishID;
    }

    public void setDishName(String dishName) {
        this.dishName = dishName;
    }

    public void setRating(float rating) {
        this.rating = rating;
    }

    public void setRestuarantID(int restuarantID) {
        this.restuarantID = restuarantID;
    }
}
