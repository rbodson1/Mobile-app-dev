package com.example.restaurantrater;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.sql.SQLException;

public class RestaurantDataSource {
    private SQLiteDatabase database;
    private DBRestaurantHelper dbHelper;

    public RestaurantDataSource(Context context) {
        dbHelper = new DBRestaurantHelper(context);
    }

    public void open() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }


    public boolean insertRestaurant(Restaurant r) {
        boolean didSucceed = false;
        try {
            ContentValues initialValues = new ContentValues();

            initialValues.put("streetaddress", r.getStreetAddress());
            initialValues.put("city", r.getCity());
            initialValues.put("state", r.getState());
            initialValues.put("zipcode", r.getZipCode());

            didSucceed = database.insert("restaurant", null, initialValues) > 0;

        }
        catch (Exception e) {
            //Do nothing -will return false if there is an exception
        }
        return didSucceed;
    }

    public boolean updateRestuarant(Restaurant r) {
        boolean didSucceed = false;
        try {
            long rowid = (long) r.getRestaurantID();
            ContentValues updateValues = new ContentValues();

            updateValues.put("streetaddress", r.getStreetAddress());
            updateValues.put("city", r.getCity());
            updateValues.put("state", r.getState());
            updateValues.put("zipcode", r.getZipCode());

            didSucceed = database.update("restaurant", updateValues, "_id=" + rowid, null) > 0;
        }
        catch (Exception e) {
            //Do nothing -will return false if there is an exception
        }
        return didSucceed;
    }

    public boolean insertDish(Dish d) {
        boolean didSucceed = false;
        try {
            ContentValues initialValues = new ContentValues();

            initialValues.put("name", d.getDishName());
            initialValues.put("type", d.getType());
            initialValues.put("rating", d.getRating());
            initialValues.put("restaurantId", d.getRestuarantID());

            didSucceed = database.insert("dish", null, initialValues) > 0;

        }
        catch (Exception e) {
            //Do nothing -will return false if there is an exception
        }
        return didSucceed;
    }

    public boolean updateDish(Dish d) {
        boolean didSucceed = false;
        try {
            long rowid = (long) d.getDishID();
            ContentValues updateValues = new ContentValues();

            updateValues.put("name", d.getDishName());
            updateValues.put("type", d.getType());
            updateValues.put("rating", d.getRating());
            updateValues.put("restaurantId", d.getRestuarantID());

            didSucceed = database.update("dish", updateValues, "dishId=" + rowid, null) > 0;
        }
        catch (Exception e) {
            //Do nothing -will return false if there is an exception
        }
        return didSucceed;
    }

    public int getLastRestaurantId() {
        int lastId;
        try {
            String query = "Select MAX(_id) from restaurant";
            Cursor cursor = database.rawQuery(query, null);

            cursor.moveToFirst();
            lastId = cursor.getInt(0);
            cursor.close();
        }
        catch (Exception e) {
            lastId = -1;
        }
        return lastId;
    }

}
