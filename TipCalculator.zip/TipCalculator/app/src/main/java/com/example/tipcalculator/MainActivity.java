package com.example.tipcalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initFifteenButton();
        initEighteenButton();
        initTwentyButton();
    }

    private void initFifteenButton() {
        Button button = findViewById(R.id.button_fifteen);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText editText = findViewById(R.id.editText_billAmount);
                TextView textView = findViewById(R.id.textView_total);

                double bill = Double.valueOf(editText.getText().toString());
                double tip = bill * .15;
                double total = bill + tip;

                textView.setText(String.format("Tip: $%s, Total Bill: $%s", tip, total));
            }
        });
    }

    private void initEighteenButton() {
        Button button = findViewById(R.id.button_eighteen);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText editText = findViewById(R.id.editText_billAmount);
                TextView textView = findViewById(R.id.textView_total);

                double bill = Double.valueOf(editText.getText().toString());
                double tip = bill * .18;
                double total = bill + tip;

                textView.setText(String.format("Tip: $%s, Total Bill: $%s", tip, total));
            }
        });
    }

    private void initTwentyButton() {
        Button button = findViewById(R.id.button_twenty);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText editText = findViewById(R.id.editText_billAmount);
                TextView textView = findViewById(R.id.textView_total);

                double bill = Double.valueOf(editText.getText().toString());
                double tip = bill * .2;
                double total = bill + tip;

                textView.setText(String.format("Tip: $%s, Total Bill: $%s", tip, total));
            }
        });
    }
}
