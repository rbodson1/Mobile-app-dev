package com.example.hotspots;

import java.io.Serializable;

//The Serializable interface allows this object to be passed to the rating dialog via a bundle
public class HotSpot implements Serializable {
    private int hotSpotId;
    private String hotSpot;
    private String streetAddress;
    private String city;
    private String state;
    private String zipCode;
    private float beerRating;
    private float wineRating;
    private float musicRating;

    public HotSpot() {
        hotSpotId = -1;
        beerRating = 0;
        wineRating = 0;
        musicRating = 0;
    }

    public float getBeerRating() {
        return beerRating;
    }

    public float getMusicRating() {
        return musicRating;
    }

    public float getWineRating() {
        return wineRating;
    }

    public int getHotSpotId() {
        return hotSpotId;
    }

    public String getCity() {
        return city;
    }

    public String getHotSpot() {
        return hotSpot;
    }

    public String getState() {
        return state;
    }

    public String getStreetAddress() {
        return streetAddress;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setBeerRating(float beerRating) {
        this.beerRating = beerRating;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setMusicRating(float musicRating) {
        this.musicRating = musicRating;
    }

    public void setHotSpot(String hotSpot) {
        this.hotSpot = hotSpot;
    }

    public void setHotSpotId(int hotSpotId) {
        this.hotSpotId = hotSpotId;
    }

    public void setState(String state) {
        this.state = state;
    }

    public void setStreetAddress(String streetAddress) {
        this.streetAddress = streetAddress;
    }

    public void setWineRating(float wineRating) {
        this.wineRating = wineRating;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }
}
