package com.example.hotspots;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DBHotSpotHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "myhotspots.db";
    private static final int DATABASE_VERSION = 1;

    // Database creation sql statement
    private static final String CREATE_TABLE_RESTAURANT =
            "create table hotspot (_id integer primary key autoincrement, hotspotname text, "
                    + "streetaddress text, city text, state text, zipcode text, beerrating real, "
                    + "winerating real, musicrating real);";

    public DBHotSpotHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_RESTAURANT);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.w(DBHotSpotHelper.class.getName(),
                "Upgrading database from version " + oldVersion + " to "
                        + newVersion + ", which will destroy all old data");
        db.execSQL("DROP TABLE IF EXISTS hotspot");
        onCreate(db);
    }


}
