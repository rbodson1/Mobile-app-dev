package com.example.hotspots;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RatingBar;

import androidx.fragment.app.DialogFragment;

public class HotSpotRatingDialog extends DialogFragment {

    public interface SaveRatingListener {
        void didFinishRaterDialog(HotSpot hotspot);
    }

    public HotSpotRatingDialog() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.rating_dialog, container);

        //get the restaurant serializable object from the bundle and cast it to a restaurant object
        final HotSpot hotSpot = (HotSpot) getArguments().getSerializable("hotSpot");

        getDialog().setTitle("Rate HotSpot!");

        final RatingBar ratingBarBeer = view.findViewById(R.id.ratingBar_beer);
        final RatingBar ratingBarWine = view.findViewById(R.id.ratingBar_wine);
        final RatingBar ratingBarMusic = view.findViewById(R.id.ratingBar_music);

        Button button = view.findViewById(R.id.button_save);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                hotSpot.setBeerRating(ratingBarBeer.getRating());
                hotSpot.setWineRating(ratingBarWine.getRating());
                hotSpot.setMusicRating(ratingBarMusic.getRating());
                saveRating(hotSpot);
            }
        });

        Button cancel = view.findViewById(R.id.button_cancel);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getDialog().dismiss();
            }
        });


        return view;
    }

    private void saveRating(HotSpot hotSpot) {
        SaveRatingListener activity = (SaveRatingListener) getActivity();
        activity.didFinishRaterDialog(hotSpot);
        getDialog().dismiss();
    }




}
