package com.example.hotspots;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements HotSpotRatingDialog.SaveRatingListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initRatingButton();
    }

    private void initRatingButton() {
        Button button = findViewById(R.id.button_rating);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                HotSpot hotSpot = new HotSpot();
                EditText editName = findViewById(R.id.editText_hotspot);
                EditText editStreet = findViewById(R.id.editText_address);
                EditText editCity = findViewById(R.id.editText_city);
                EditText editState = findViewById(R.id.editText_state);
                EditText editZip = findViewById(R.id.editText_zipcode);

                hotSpot.setHotSpot(editName.getText().toString());
                hotSpot.setStreetAddress(editStreet.getText().toString());
                hotSpot.setCity(editCity.getText().toString());
                hotSpot.setState(editState.getText().toString());
                hotSpot.setZipCode(editZip.getText().toString());

                FragmentManager fragmentManager = getSupportFragmentManager();
                HotSpotRatingDialog restaurantRaterDialog = new HotSpotRatingDialog();

                //The following three lines create a bundle, add the restaurant object to it
                //and passes the bundle to the dialog.
                Bundle args = new Bundle();
                args.putSerializable("hotSpot", hotSpot);
                restaurantRaterDialog.setArguments(args);

                restaurantRaterDialog.show(fragmentManager, "RateMeal");
            }
        });
    }

    @Override
    public void didFinishRaterDialog(HotSpot hotspot) {
        double averageRating = 0;
        averageRating += hotspot.getBeerRating();
        averageRating += hotspot.getMusicRating();
        averageRating += hotspot.getWineRating();
        averageRating = averageRating/3;

        TextView textView = findViewById(R.id.textView_averageRating);
        textView.setText(String.valueOf(averageRating));

        HotSpotDataSource ds = new HotSpotDataSource(MainActivity.this);
        boolean wasSuccessful;
        try {
            ds.open();
            if (hotspot.getHotSpotId() == -1) {
                wasSuccessful = ds.insertHotSpot(hotspot);
            }
            else {
                wasSuccessful = ds.updateHotSpot(hotspot);
            }
            ds.close();

        }
        catch (Exception e) {
            wasSuccessful = false;
            ds.close();
        }

        if (wasSuccessful) {
            Toast.makeText(MainActivity.this, "HotSpot Saved!", Toast.LENGTH_LONG).show();
        }
        else {
            Toast.makeText(MainActivity.this, "HotSpot Save Failed!", Toast.LENGTH_LONG).show();
        }

    }
}
