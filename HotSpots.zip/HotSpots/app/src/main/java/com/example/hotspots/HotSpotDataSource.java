package com.example.hotspots;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import java.sql.SQLException;

public class HotSpotDataSource {
    private SQLiteDatabase database;
    private DBHotSpotHelper dbHelper;

    public HotSpotDataSource(Context context) {
        dbHelper = new DBHotSpotHelper(context);
    }

    public void open() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }


    public boolean insertHotSpot(HotSpot h) {
        boolean didSucceed = false;
        try {
            ContentValues initialValues = new ContentValues();

            initialValues.put("hotspotname", h.getHotSpot());
            initialValues.put("streetaddress", h.getStreetAddress());
            initialValues.put("city", h.getCity());
            initialValues.put("state", h.getState());
            initialValues.put("zipcode", h.getZipCode());
            initialValues.put("beerrating", h.getBeerRating());
            initialValues.put("winerating", h.getWineRating());
            initialValues.put("musicrating", h.getMusicRating());


            didSucceed = database.insert("hotspot", null, initialValues) > 0;

        }
        catch (Exception e) {
            //Do nothing -will return false if there is an exception
        }
        return didSucceed;
    }

    public boolean updateHotSpot(HotSpot h) {
        boolean didSucceed = false;
        try {
            long rowid = (long) h.getHotSpotId();
            ContentValues updateValues = new ContentValues();

            updateValues.put("hotspotname", h.getHotSpot());
            updateValues.put("streetaddress", h.getStreetAddress());
            updateValues.put("city", h.getCity());
            updateValues.put("state", h.getState());
            updateValues.put("zipcode", h.getZipCode());
            updateValues.put("beerrating", h.getBeerRating());
            updateValues.put("winerating", h.getWineRating());
            updateValues.put("musicrating", h.getMusicRating());

            didSucceed = database.update("hotspot", updateValues, "_id=" + rowid, null) > 0;
        }
        catch (Exception e) {
            //Do nothing -will return false if there is an exception
        }
        return didSucceed;
    }

}
