//
//  ViewController.swift
//  Interface Builder
//
//  Created by Todd Perkins on 11/15/19.
//  Copyright © 2019 Todd Perkins. All rights reserved.
//

import Cocoa

class ViewController: NSViewController {
    
    @IBOutlet weak var textField: NSTextField!
    @IBOutlet weak var label: NSTextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    @IBAction func buttonWasPressed(_ sender: Any) {
        label.stringValue = "Hello, \(textField.stringValue)!"
    }
    
    override var representedObject: Any? {
        didSet {
        // Update the view, if already loaded.
        }
    }


}

