This is my first simple android app with android studio. It doesn’t do much, it only says hello to the name entered.

To use this app:

1. You will need to enter your name on the green line under the statement “Please enter
your name”.

2. After you enter your name, you will then need to click on the button that says “Click me”.

After you click the button, a message will be displayed that reads “Hello, (your name)”.