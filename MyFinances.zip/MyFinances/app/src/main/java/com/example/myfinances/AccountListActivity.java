package com.example.myfinances;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;

public class AccountListActivity extends AppCompatActivity {
    RecyclerView accountList;
    AccountAdapter accountAdapter;

    ArrayList<Account> accounts;
    private View.OnClickListener onItemClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            RecyclerView.ViewHolder viewHolder = (RecyclerView.ViewHolder) view.getTag();
            int position = viewHolder.getAdapterPosition();
            String accountNumber = accounts.get(position).getAccountNumber();
            Intent intent = new Intent(AccountListActivity.this, MainActivity.class);
            intent.putExtra("accountId", accountNumber);
            startActivity(intent);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_list);

        initNewAccountButton();
    }



    @Override
    public void onResume() {
        super.onResume();

       AccountDataSource ds = new AccountDataSource(this);
        try {
            ds.open();
            accounts = ds.getAccounts();
            ds.close();
            if (accounts.size() > 0) {
                accountList = findViewById(R.id.recyclerView_accounts);
                RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
                accountList.setLayoutManager(layoutManager);
                accountAdapter = new AccountAdapter(accounts, this);
                accountAdapter.setOnItemClickListener(onItemClickListener);
                accountList.setAdapter(accountAdapter);
            }
            else {
                Intent intent = new Intent(AccountListActivity.this, MainActivity.class);
                startActivity(intent);
            }
        }
        catch (Exception e) {
            Toast.makeText(this, "Error retrieving contacts", Toast.LENGTH_LONG).show();
        }

    }

    private void initNewAccountButton() {
        Button button = findViewById(R.id.button_new);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AccountListActivity.this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });

    }
}
