package com.example.myfinances;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import java.sql.SQLException;

public class AccountDataSource {
    private SQLiteDatabase database;
    private DBAccountHelper dbHelper;

    public AccountDataSource(Context context) {
        dbHelper = new DBAccountHelper(context);
    }

    public void open() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public boolean insertAccount(Account a) {
        boolean didSucceed = false;
        try {
            ContentValues initialValues = new ContentValues();

            initialValues.put("accountnumber", a.getAccountNumber());
            initialValues.put("type", a.getType());
            initialValues.put("currentbalance", a.getCurrentBalance());
            initialValues.put("initialbalance", a.getInitialBalance());
            initialValues.put("interestrate", a.getInterestRate());
            initialValues.put("payment", a.getPayment());


            didSucceed = database.insert("account", null, initialValues) > 0;

            if (!didSucceed) {
                updateAccount(a);
            }
        }
        catch (Exception e) {
            //Do nothing -will return false if there is an exception
        }
        return didSucceed;
    }

    public boolean updateAccount(Account a) {
        boolean didSucceed = false;
        try {
            ContentValues updateValues = new ContentValues();

            updateValues.put("accountnumber", a.getAccountNumber());
            updateValues.put("type", a.getType());
            updateValues.put("currentbalance", a.getCurrentBalance());
            updateValues.put("initialbalance", a.getInitialBalance());
            updateValues.put("interestrate", a.getInterestRate());
            updateValues.put("payment", a.getPayment());

            didSucceed = database.update("account", updateValues, "accountnumber='" + a.getAccountNumber() + "'", null) > 0;
        }
        catch (Exception e) {
            //Do nothing -will return false if there is an exception
        }
        return didSucceed;
    }

}
