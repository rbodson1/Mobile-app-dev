package com.example.myfinances;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.sql.SQLException;
import java.util.ArrayList;

public class AccountDataSource {
    private SQLiteDatabase database;
    private DBAccountHelper dbHelper;

    public AccountDataSource(Context context) {
        dbHelper = new DBAccountHelper(context);
    }

    public void open() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public boolean insertAccount(Account a) {
        boolean didSucceed = false;
        try {
            ContentValues initialValues = new ContentValues();

            initialValues.put("accountnumber", a.getAccountNumber());
            initialValues.put("type", a.getType());
            initialValues.put("currentbalance", a.getCurrentBalance());
            initialValues.put("initialbalance", a.getInitialBalance());
            initialValues.put("interestrate", a.getInterestRate());
            initialValues.put("payment", a.getPayment());


            didSucceed = database.insert("account", null, initialValues) > 0;

            if (!didSucceed) {
                updateAccount(a);
            }
        }
        catch (Exception e) {
            //Do nothing -will return false if there is an exception
        }
        return didSucceed;
    }

    public boolean updateAccount(Account a) {
        boolean didSucceed = false;
        try {
            ContentValues updateValues = new ContentValues();

            updateValues.put("accountnumber", a.getAccountNumber());
            updateValues.put("type", a.getType());
            updateValues.put("currentbalance", a.getCurrentBalance());
            updateValues.put("initialbalance", a.getInitialBalance());
            updateValues.put("interestrate", a.getInterestRate());
            updateValues.put("payment", a.getPayment());

            didSucceed = database.update("account", updateValues, "accountnumber='" + a.getAccountNumber() + "'", null) > 0;
        }
        catch (Exception e) {
            //Do nothing -will return false if there is an exception
        }
        return didSucceed;
    }

    public ArrayList<Account> getAccounts() {
        ArrayList<Account> accounts = new ArrayList<>();
        try {
            String query = "SELECT  * FROM account";
            Cursor cursor = database.rawQuery(query, null);

            Account newAccount;
            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                newAccount = new Account();
                newAccount.setAccountNumber(cursor.getString(0));
                newAccount.setType(cursor.getString(1));
                newAccount.setCurrentBalance(cursor.getDouble(2));
                newAccount.setInitialBalance(cursor.getDouble(3));
                newAccount.setInterestRate(cursor.getDouble(4));
                newAccount.setPayment(cursor.getDouble(5));
                accounts.add(newAccount);
                cursor.moveToNext();
            }
            cursor.close();
        }
        catch (Exception e) {
            accounts = new ArrayList<>();
        }
        return accounts;
    }

    public Account getAccount(String id) {
        Account newAccount = new Account();
        try {
            String query = "SELECT  * FROM account WHERE accountnumber = '" + id + "'";
            Cursor cursor = database.rawQuery(query, null);

            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                newAccount.setAccountNumber(cursor.getString(0));
                newAccount.setType(cursor.getString(1));
                newAccount.setCurrentBalance(cursor.getDouble(2));
                newAccount.setInitialBalance(cursor.getDouble(3));
                newAccount.setInterestRate(cursor.getDouble(4));
                newAccount.setPayment(cursor.getDouble(5));
                cursor.moveToNext();
            }
            cursor.close();
        }
        catch (Exception e) {
            newAccount = new Account();
        }
        return newAccount;
    }

}
