package com.example.myfinances;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initRadioGroup();
        initSaveButton();
        initCancelButton();
    }


    private void initRadioGroup() {
        RadioGroup rg = findViewById(R.id.radioGroup);
        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                setEnabled();
           }
        });
    }

    private void setEnabled() {
        RadioButton rbCd = findViewById(R.id.radioButton_CD);
        RadioButton rbLoan = findViewById(R.id.radioButton_loan);

        EditText editInitialBalance = findViewById(R.id.editText_initialBalance);
        EditText editInterestRate = findViewById(R.id.editText_interestRate);
        EditText editPayment = findViewById(R.id.editText_payment);

        if (rbCd.isChecked()) {
            editInitialBalance.setEnabled(true);
            editInterestRate.setEnabled(true);
            editPayment.setEnabled(false);
        }
        else if (rbLoan.isChecked()) {
            editInitialBalance.setEnabled(true);
            editInterestRate.setEnabled(true);
            editPayment.setEnabled(true);
        }
        else {
            editInitialBalance.setEnabled(false);
            editInterestRate.setEnabled(false);
            editPayment.setEnabled(false);
        }
    }

    private void initSaveButton() {
        Button button = findViewById(R.id.button_save);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RadioButton rbCd = findViewById(R.id.radioButton_CD);
                RadioButton rbLoan = findViewById(R.id.radioButton_loan);

                EditText editAccountNumber = findViewById(R.id.editText_accountNumber);
                EditText editCurrentBalance = findViewById(R.id.editText_currentBalance);
                EditText editInitialBalance = findViewById(R.id.editText_initialBalance);
                EditText editInterestRate = findViewById(R.id.editText_interestRate);
                EditText editPayment = findViewById(R.id.editText_payment);

                Account newAccount = new Account();

                if (rbCd.isChecked()) {
                    newAccount.setType("CD");
                    newAccount.setAccountNumber(editAccountNumber.getText().toString());
                    newAccount.setCurrentBalance(Double.valueOf(editCurrentBalance.getText().toString()));
                    newAccount.setInitialBalance(Double.valueOf(editInitialBalance.getText().toString()));
                    newAccount.setInterestRate(Double.valueOf(editInterestRate.getText().toString()));
                }
                else if (rbLoan.isChecked()) {
                    newAccount.setType("Loan");
                    newAccount.setAccountNumber(editAccountNumber.getText().toString());
                    newAccount.setCurrentBalance(Double.valueOf(editCurrentBalance.getText().toString()));
                    newAccount.setInitialBalance(Double.valueOf(editInitialBalance.getText().toString()));
                    newAccount.setInterestRate(Double.valueOf(editInterestRate.getText().toString()));
                    newAccount.setPayment(Double.valueOf(editPayment.getText().toString()));
                }
                else {
                    newAccount.setType("Checking");
                    newAccount.setAccountNumber(editAccountNumber.getText().toString());
                    newAccount.setCurrentBalance(Double.valueOf(editCurrentBalance.getText().toString()));
                }

                AccountDataSource ds = new AccountDataSource(MainActivity.this);
                boolean wasSuccessful;
                try {
                    ds.open();
                    wasSuccessful = ds.insertAccount(newAccount);
                    ds.close();
                }
                catch (Exception e) {
                    wasSuccessful = false;
                }

                if (wasSuccessful) {
                    Toast.makeText(MainActivity.this, "Account Saved!", Toast.LENGTH_LONG).show();
                }
                else {
                    Toast.makeText(MainActivity.this, "Account Save Failed", Toast.LENGTH_LONG).show();
                }


                editAccountNumber.setText("");
                editCurrentBalance.setText("");
                editInitialBalance.setText("");
                editInterestRate.setText("");
                editPayment.setText("");

                setEnabled();
            }
        });
    }

    private void initCancelButton() {
        Button button = findViewById(R.id.button_cancel);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText editAccountNumber = findViewById(R.id.editText_accountNumber);
                EditText editCurrentBalance = findViewById(R.id.editText_currentBalance);
                EditText editInitialBalance = findViewById(R.id.editText_initialBalance);
                EditText editInterestRate = findViewById(R.id.editText_interestRate);
                EditText editPayment = findViewById(R.id.editText_payment);

                editAccountNumber.setText("");
                editCurrentBalance.setText("");
                editInitialBalance.setText("");
                editInterestRate.setText("");
                editPayment.setText("");

                setEnabled();
            }
        });
    }
}
