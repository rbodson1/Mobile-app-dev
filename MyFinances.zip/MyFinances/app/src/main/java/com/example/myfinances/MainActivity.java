package com.example.myfinances;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Account currentAccount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initRadioGroup();
        initSaveButton();
        initCancelButton();
        initAccountListButton();

        Bundle extras = getIntent().getExtras();
        if(extras != null) {
            initAccount(extras.getString("accountId"));
        }
        else {
            currentAccount = new Account();
        }

    }

    private void initAccount(String id) {
        RadioButton rbCd = findViewById(R.id.radioButton_CD);
        RadioButton rbLoan = findViewById(R.id.radioButton_loan);
        RadioButton rbChecking = findViewById(R.id.radioButton_checkingAccount);

        EditText editAccountNumber = findViewById(R.id.editText_accountNumber);
        EditText editCurrentBalance = findViewById(R.id.editText_currentBalance);
        EditText editInitialBalance = findViewById(R.id.editText_initialBalance);
        EditText editInterestRate = findViewById(R.id.editText_interestRate);
        EditText editPayment = findViewById(R.id.editText_payment);

        AccountDataSource ds = new AccountDataSource(MainActivity.this);
        try {
            ds.open();
            currentAccount = ds.getAccount(id);
            ds.close();

            if (currentAccount.getType().equalsIgnoreCase("Loan")) {
                rbLoan.setChecked(true);
            }
            else if(currentAccount.getType().equalsIgnoreCase("Checking")) {
                rbChecking.setChecked(true);
            }
            else {
                rbCd.setChecked(true);
            }

            setEnabled();

            editAccountNumber.setText(currentAccount.getAccountNumber());
            editCurrentBalance.setText(String.valueOf(currentAccount.getCurrentBalance()));
            editInitialBalance.setText(String.valueOf(currentAccount.getInitialBalance()));
            editInterestRate.setText(String.valueOf(currentAccount.getInterestRate()));
            editPayment.setText(String.valueOf(currentAccount.getPayment()));

        }
        catch (Exception e) {
            Toast.makeText(MainActivity.this, "Account Retrieval Failed", Toast.LENGTH_LONG).show();
        }


    }

    private void initRadioGroup() {
        RadioGroup rg = findViewById(R.id.radioGroup);
        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                setEnabled();
           }
        });
    }

    private void setEnabled() {
        RadioButton rbCd = findViewById(R.id.radioButton_CD);
        RadioButton rbLoan = findViewById(R.id.radioButton_loan);

        EditText editInitialBalance = findViewById(R.id.editText_initialBalance);
        EditText editInterestRate = findViewById(R.id.editText_interestRate);
        EditText editPayment = findViewById(R.id.editText_payment);

        if (rbCd.isChecked()) {
            editInitialBalance.setEnabled(true);
            editInterestRate.setEnabled(true);
            editPayment.setEnabled(false);
        }
        else if (rbLoan.isChecked()) {
            editInitialBalance.setEnabled(true);
            editInterestRate.setEnabled(true);
            editPayment.setEnabled(true);
        }
        else {
            editInitialBalance.setEnabled(false);
            editInterestRate.setEnabled(false);
            editPayment.setEnabled(false);
        }
    }

    private void initSaveButton() {
        Button button = findViewById(R.id.button_save);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RadioButton rbCd = findViewById(R.id.radioButton_CD);
                RadioButton rbLoan = findViewById(R.id.radioButton_loan);

                EditText editAccountNumber = findViewById(R.id.editText_accountNumber);
                EditText editCurrentBalance = findViewById(R.id.editText_currentBalance);
                EditText editInitialBalance = findViewById(R.id.editText_initialBalance);
                EditText editInterestRate = findViewById(R.id.editText_interestRate);
                EditText editPayment = findViewById(R.id.editText_payment);

                if (rbCd.isChecked()) {
                    currentAccount.setType("CD");
                    currentAccount.setCurrentBalance(Double.valueOf(editCurrentBalance.getText().toString()));
                    currentAccount.setInitialBalance(Double.valueOf(editInitialBalance.getText().toString()));
                    currentAccount.setInterestRate(Double.valueOf(editInterestRate.getText().toString()));
                }
                else if (rbLoan.isChecked()) {
                    currentAccount.setType("Loan");
                    currentAccount.setCurrentBalance(Double.valueOf(editCurrentBalance.getText().toString()));
                    currentAccount.setInitialBalance(Double.valueOf(editInitialBalance.getText().toString()));
                    currentAccount.setInterestRate(Double.valueOf(editInterestRate.getText().toString()));
                    currentAccount.setPayment(Double.valueOf(editPayment.getText().toString()));
                }
                else {
                    currentAccount.setType("Checking");
                    currentAccount.setCurrentBalance(Double.valueOf(editCurrentBalance.getText().toString()));
                }

                AccountDataSource ds = new AccountDataSource(MainActivity.this);
                boolean wasSuccessful;
                try {
                    ds.open();
                    if (currentAccount.getAccountNumber() == null) {
                        currentAccount.setAccountNumber(editAccountNumber.getText().toString());
                        wasSuccessful = ds.insertAccount(currentAccount);
                    }
                    else {
                        wasSuccessful = ds.updateAccount(currentAccount);
                    }
                    ds.close();
                }
                catch (Exception e) {
                    wasSuccessful = false;
                }

                if (wasSuccessful) {
                    Toast.makeText(MainActivity.this, "Account Saved!", Toast.LENGTH_LONG).show();
                }
                else {
                    Toast.makeText(MainActivity.this, "Account Save Failed", Toast.LENGTH_LONG).show();
                }


                editAccountNumber.setText("");
                editCurrentBalance.setText("");
                editInitialBalance.setText("");
                editInterestRate.setText("");
                editPayment.setText("");

                setEnabled();
            }
        });
    }

    private void initCancelButton() {
        Button button = findViewById(R.id.button_cancel);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText editAccountNumber = findViewById(R.id.editText_accountNumber);
                EditText editCurrentBalance = findViewById(R.id.editText_currentBalance);
                EditText editInitialBalance = findViewById(R.id.editText_initialBalance);
                EditText editInterestRate = findViewById(R.id.editText_interestRate);
                EditText editPayment = findViewById(R.id.editText_payment);

                editAccountNumber.setText("");
                editCurrentBalance.setText("");
                editInitialBalance.setText("");
                editInterestRate.setText("");
                editPayment.setText("");

                setEnabled();
            }
        });
    }

    private void initAccountListButton() {
        Button button = findViewById(R.id.button_list);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AccountListActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });
    }
}
