package com.example.myfinances;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.NumberFormat;
import java.util.ArrayList;

public class AccountAdapter extends RecyclerView.Adapter{
    private ArrayList<Account> accountData;
    private View.OnClickListener mOnItemClickListener;
    private boolean isDeleting;
    private Context parentContext;

    public class AccountViewHolder extends RecyclerView.ViewHolder {

        public TextView textViewType;
        public TextView textViewNumber;
        public TextView textViewBalance;
        public AccountViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewType = itemView.findViewById(R.id.textView_type);
            textViewNumber = itemView.findViewById(R.id.textView_number);
            textViewBalance = itemView.findViewById(R.id.textView_balance);

            itemView.setTag(this);
            itemView.setOnClickListener(mOnItemClickListener);
        }

        public TextView getTextViewType() {
            return textViewType;
        }
        public TextView getTextViewNumber() {
            return textViewNumber;
        }
        public TextView getTextViewBalance() {
            return textViewBalance;
        }
    }

    public AccountAdapter(ArrayList<Account> arrayList, Context context) {
        accountData = arrayList;
        parentContext = context;
    }

    public void setOnItemClickListener(View.OnClickListener itemClickListener) {
        mOnItemClickListener = itemClickListener;
    }


    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.account_list, parent, false);
        return new AccountViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position) {
        AccountViewHolder cvh = (AccountViewHolder) holder;
        cvh.getTextViewType().setText(accountData.get(position).getType());
        cvh.getTextViewNumber().setText(accountData.get(position).getAccountNumber());
        double balance = accountData.get(position).getCurrentBalance();
        NumberFormat formatter = NumberFormat.getCurrencyInstance();
        cvh.getTextViewBalance().setText(formatter.format(balance));
    }

    @Override
    public int getItemCount() {
        return accountData.size();
    }


}


