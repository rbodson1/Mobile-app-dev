package com.example.contractorcalculator;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.fragment.app.DialogFragment;

public class TaxRateDialog extends DialogFragment {

    float newTaxRate;

    public interface SaveRateListener {
        void didFinishNewRateDialog(float taxRate);
    }

    public TaxRateDialog() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.new_tax_rate, container);

        getDialog().setTitle("Enter New Rate");

        final EditText txtRate = view.findViewById(R.id.editText_newRate);
        Button okButton = view.findViewById(R.id.button_OK);
        okButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                 saveItem(txtRate.getText().toString());
            }
        });
        Button cancelButton = view.findViewById(R.id.button_cancel);
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getDialog().dismiss();
            }
        });
        return view;
    }

    private void saveItem(String newRate) {
        SaveRateListener activity = (SaveRateListener) getActivity();
        activity.didFinishNewRateDialog(Float.valueOf(newRate));
        getDialog().dismiss();
    }
}

