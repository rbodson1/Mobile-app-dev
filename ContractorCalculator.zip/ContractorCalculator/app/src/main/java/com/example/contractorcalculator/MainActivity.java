package com.example.contractorcalculator;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements TaxRateDialog.SaveRateListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initCalculateButton();
        initChangeRateButton();

        TextView txtRate = findViewById(R.id.textView_displayedRate);
        float taxRate = getSharedPreferences("ContractCalculatorPreferences", Context.MODE_PRIVATE).getFloat("currentTaxRate", .05F);
        txtRate.setText(String.valueOf(taxRate));
    }

    private void initCalculateButton() {
        Button button = findViewById(R.id.button_calculate);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText editTextLabor = findViewById(R.id.editText_labor);
                EditText editTextMaterial = findViewById(R.id.editText_material);

                TextView txtSub = findViewById(R.id.textView_subtotal_calculation);
                TextView txtTax = findViewById(R.id.textView_tax_calculation);
                TextView txtTotal = findViewById(R.id.textView_total_calculation);
                TextView txtRate = findViewById(R.id.textView_displayedRate);

                double labor = Double.valueOf(editTextLabor.getText().toString());
                double materials = Double.valueOf(editTextMaterial.getText().toString());

                final double taxRate = Double.valueOf(txtRate.getText().toString());

                double subtotal = labor + materials;
                double tax = subtotal * taxRate;
                double total = subtotal + tax;

                txtSub.setText(String.valueOf(subtotal));
                txtTax.setText(String.valueOf(tax));
                txtTotal.setText(String.valueOf(total));

            }
        });
    }

    private void initChangeRateButton() {
        Button button = findViewById(R.id.button_changeRate);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentManager fm = getSupportFragmentManager();
                TaxRateDialog rateDialog = new TaxRateDialog();
                rateDialog.show(fm, "Rate");
            }
        });
    }

    @Override
    public void didFinishNewRateDialog(float taxRate) {
        getSharedPreferences("ContractCalculatorPreferences", Context.MODE_PRIVATE).edit().putFloat("currentTaxRate", taxRate).apply();
        TextView txtDisplayRate = findViewById(R.id.textView_displayedRate);
        txtDisplayRate.setText(String.valueOf(taxRate));
    }
}
